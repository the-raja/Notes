package com.kunal.interfaces;

public interface Brake {
    void brake();
//    void start();
}
