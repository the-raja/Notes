package com.kunal.properties.inheritance;

public class BoxColor extends BoxWeight {

}
