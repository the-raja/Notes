package com.kunal.packages.a;

import static com.kunal.packages.b.Message.message;

public class Greeting {
    public static void main(String[] args) {
        System.out.println("Hello world");
        message();
    }
}
