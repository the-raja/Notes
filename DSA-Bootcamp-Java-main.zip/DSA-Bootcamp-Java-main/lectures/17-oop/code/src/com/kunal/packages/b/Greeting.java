package com.kunal.packages.b;

public class Greeting {
    public static void main(String[] args) {
        System.out.println(" I am awesome");
    }
}
