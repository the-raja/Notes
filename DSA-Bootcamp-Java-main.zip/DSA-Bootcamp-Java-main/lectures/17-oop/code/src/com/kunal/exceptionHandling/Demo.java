package com.kunal.exceptionHandling;

public class Demo {
    public static void main(String[] args) {
        Main.divide(3, 0);
    }
}
