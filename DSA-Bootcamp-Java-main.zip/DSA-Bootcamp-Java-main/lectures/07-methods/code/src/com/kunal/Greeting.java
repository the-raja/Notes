package com.kunal;

public class Greeting {
    public static void main(String[] args) {
        greeting();
    }
    static void greeting() {
        System.out.println("Hello World");
    }
}
