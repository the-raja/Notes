package com.kunal;

public class PrettyPrinting {
    public static void main(String[] args) {
        float a = 453.1274f;
//        System.out.printf("Formatted number is %.2f", a);

//        System.out.printf("Pie: %.3f", Math.PI);

        System.out.printf("Hello my name is %s and I am %s", "Kunal", "Cool");
    }
}
